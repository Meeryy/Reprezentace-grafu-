﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReprezentovaniGrafu
{
    public class Graph
    {
        private List<SortedSet<int>> myGraph = new List<SortedSet<int>>();
        private int vertexCount = 0;
        public Graph(int vertexCount)
        {
            this.vertexCount = vertexCount;
            for (int i = 0; i < vertexCount; i++)
            {
                myGraph.Add(new SortedSet<int>());
            }
        }
        /// <summary>
        /// Metoda prida hranu do grafu
        /// </summary>
        /// <param name="vertex1"> [pcatecni vrchol hrany</param>
        /// <param name="vertex2"> koncovy vrchol hrany</param>
        /// <returns> true pokud se podarilo pridat do grafu</returns>
        public bool addEdge(int from, int to)
        {
            if (!IsVertex(from)) return false;
            // myGraph[from].Add[to] co to je
             if (!myGraph[from].Add(to)) //from = index, to = naslednik
            {
                return false;
            }
            if (!myGraph[to].Add(from))//orientovany graf
            {
                return false;
            }
             return true;

        }
        public bool IsVertex(int vertex)
        {
            return vertex >=0 && vertex < myGraph.Count;
        }

        public override string ToString()
        {
            string print = "";
            int i = 0;
            foreach (var vertexSet in myGraph)
            {
                print += i + " -> ";
                foreach (var item2 in vertexSet)
                {
                    print += item2 + ", ";
                }
                print += "\n";
                i++;
            }
            return print; //! vez co vypisujes
        }

         
        






    }
}
