﻿namespace ReprezentovaniGrafu
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Graph graph = new Graph(4);
            graph.addEdge(0, 1);
            graph.addEdge(1, 2);
            graph.addEdge(1, 3);
            graph.addEdge(2, 3);

            Console.WriteLine(graph.ToString());



        }
    }
}